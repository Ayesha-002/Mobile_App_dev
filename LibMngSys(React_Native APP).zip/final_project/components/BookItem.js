import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const BookItem = ({ book }) => {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{book.Title || 'Untitled Book'}</Text>
      <Text style={styles.author}>By {book.Author || 'Unknown Author'}</Text>

      <View style={styles.row}>
        <Text style={styles.label}>ISBN:</Text>
        <Text style={styles.value}>{book.ISBN || 'N/A'}</Text>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>Status:</Text>
        <Text style={[styles.value, book.Status?.toLowerCase() === 'available' ? styles.available : styles.borrowed]}>
          {book.Status || 'Unknown'}
        </Text>
      </View>

      {book.LastBorrowed ? (
        <View style={styles.row}>
          <Text style={styles.label}>Last Borrowed:</Text>
          <Text style={styles.value}>{book.LastBorrowed}</Text>
        </View>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
    color: '#333',
  },
  author: {
    fontSize: 14,
    marginBottom: 10,
    color: '#555',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  label: {
    fontWeight: '600',
    width: 100,
    color: '#666',
  },
  value: {
    color: '#000',
  },
  available: {
    color: 'green',
    fontWeight: 'bold',
  },
  borrowed: {
    color: 'red',
    fontWeight: 'bold',
  },
});

export default BookItem;
