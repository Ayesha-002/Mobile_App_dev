import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchBooksFromSheet, deleteBookFromSheet, updateBookInSheet } from '../utils/api';

export const fetchBooks = createAsyncThunk('books/fetchBooks', async () => {
  const data = await fetchBooksFromSheet();
  return data;
});

const booksSlice = createSlice({
  name: 'books',
  initialState: { items: [], loading: false },
  reducers: {},
  extraReducers: builder => {
    builder
      .addCase(fetchBooks.pending, state => { state.loading = true; })
      .addCase(fetchBooks.fulfilled, (state, action) => {
        state.items = action.payload;
        state.loading = false;
      });
  }
});

export default booksSlice.reducer;
