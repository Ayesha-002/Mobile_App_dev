import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';
// Add all other screens here
import HomeScreen from '../screens/HomeScreen';
import AddBookScreen from '../screens/AddBookScreen';
import AddMemberScreen from '../screens/AddMemberScreen';
import TransScreen from '../screens/TransScreen';



const Stack = createNativeStackNavigator();

export default function HomeStackNavigator() {
  return (
    // <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="AddBook" component={AddBookScreen} />
        <Stack.Screen name="AddMember" component={AddMemberScreen} />
        <Stack.Screen name="Transaction" component={TransScreen} />
      </Stack.Navigator>
    // </NavigationContainer>
  );
}
