import React, { useState } from 'react';
import {useNavigation} from '@react-navigation/native';
import { View, Text, TextInput, Button, Alert, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';

const SHEET_URL = 'https://api.sheetbest.com/sheets/795776a2-805c-4ab8-b921-7178d51b8aa2'; // Replace with your actual Sheet.best URL

const TransactionScreen = () => {
  const [formData, setFormData] = useState({
    ID: '',
    BookID: '',
    MemberID: '',
    CheckoutDate: new Date().toISOString().split('T')[0],
    ReturnDate: '',
    Status: 'borrowed',
    LastBorrowed: new Date().toISOString().split('T')[0],
  });

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleSubmit = async () => {
    try {
      const response = await fetch(SHEET_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        Alert.alert('Success', 'Transaction recorded');
        setFormData({
          ID: '',
          BookID: '',
          MemberID: '',
          CheckoutDate: new Date().toISOString().split('T')[0],
          ReturnDate: '',
          Status: 'borrowed',
          LastBorrowed: new Date().toISOString().split('T')[0],
        });
      } else {
        Alert.alert('Error', 'Failed to record transaction');
      }
    } catch (error) {
      console.error('Transaction error:', error);
      Alert.alert('Error', 'Something went wrong');
    }
  };

  
  const nav = useNavigation();

  return (
    <ScrollView style={styles.container}>
       <TouchableOpacity onPress={() => nav.goBack()}>
        <Text style={{ fontSize: 18 }}>⬅️ Back</Text>
      </TouchableOpacity>
      <Text style={styles.title}>Add Transaction</Text>
      <TextInput style={styles.input} placeholder="ID" value={formData.ID} onChangeText={(text) => handleChange('ID', text)} />
      <TextInput style={styles.input} placeholder="Book ID" value={formData.BookID} onChangeText={(text) => handleChange('BookID', text)} />
      <TextInput style={styles.input} placeholder="Member ID" value={formData.MemberID} onChangeText={(text) => handleChange('MemberID', text)} />
      <TextInput style={styles.input} placeholder="Return Date (YYYY-MM-DD)" value={formData.ReturnDate} onChangeText={(text) => handleChange('ReturnDate', text)} />
      <Button title="Record Transaction" onPress={handleSubmit} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20, marginTop: 50 },
  title: { fontSize: 24, marginBottom: 20, fontWeight: 'bold' },
  input: { borderWidth: 1, borderColor: '#ccc', marginBottom: 15, padding: 10, borderRadius: 8 },
});

export default TransactionScreen;
