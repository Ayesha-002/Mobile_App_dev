import React from 'react';
import { View, Text, Button, StyleSheet, ScrollView, SafeAreaProvider } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>📚 Library Manager</Text>

      <View style={styles.buttonContainer}>
        <Button title="➕ Add Book" onPress={() => navigation.navigate('AddBook')} />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="➕ Add Member" onPress={() => navigation.navigate('AddMember')} />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="🔁 New Transaction" onPress={() => navigation.navigate('Transaction')} />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="⚙️ Settings" onPress={() => navigation.navigate('Settings')} />
      </View>
    </ScrollView>
  
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 60,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  buttonContainer: {
    width: '100%',
    marginBottom: 20,
  },
});

export default HomeScreen;
