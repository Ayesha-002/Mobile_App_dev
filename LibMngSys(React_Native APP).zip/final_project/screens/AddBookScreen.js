import React, { useState } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, Text, TextInput, Button, Alert, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';


const SHEET_URL = 'https://api.sheetbest.com/sheets/795776a2-805c-4ab8-b921-7178d51b8aa2'; // Replace with your actual Sheet.best URL

const AddBookScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    ID: '',
    Title: '',
    Author: '',
    ISBN: '',
    Status: 'available',
    LastBorrowed: '',
    MemID: '',
    MemName: '',
    MemEmail: '',
    MemPhone: '',
    MembershipDate: '',
    BookID: '',
    MemberID: '',
    CheckoutDate: '',
    ReturnDate: '',
  });

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleSubmit = async () => {
    try {
      console.log("start")
      const response = await fetch(SHEET_URL, {
        method: 'POST',
        mode: "cors",
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      console.log("stop",response.json(), response, response.ok, response.status, formData)
      if (response.ok) {
        Alert.alert('Success', 'Book added successfully');
        setFormData({
          ID: '',
          Title: '',
          Author: '',
          ISBN: '',
          Status: 'available',
          LastBorrowed: '',
          MemID: '',
          MemName: '',
          MemEmail: '',
          MemPhone: '',
          MembershipDate: '',
          BookID: '',
          MemberID: '',
          CheckoutDate: '',
          ReturnDate: '',
        });
      } else {
        Alert.alert('Error', 'Failed to add book');
      }
    } catch (error) {
      console.error('Error adding book:', error);
      Alert.alert('Error', 'Something went wrong');
    }
    
  };

 const nav = useNavigation();

  return (
    <ScrollView style={styles.container}>
     <TouchableOpacity onPress={() => nav.goBack()}>
        <Text style={{ fontSize: 18 }}>⬅️ Back</Text>
      </TouchableOpacity>
      <Text style={styles.title}>Add Book</Text>

      <TextInput
        style={styles.input}
        placeholder="ID"
        value={formData.ID}
        onChangeText={(text) => handleChange('ID', text)}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Title"
        value={formData.Title}
        onChangeText={(text) => handleChange('Title', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Author"
        value={formData.Author}
        onChangeText={(text) => handleChange('Author', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="ISBN"
        value={formData.ISBN}
        onChangeText={(text) => handleChange('ISBN', text)}
        keyboardType="numeric"
      />
      <Button title="Add Book" onPress={handleSubmit} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    marginTop: 50,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 15,
    padding: 10,
    borderRadius: 8,
  },
});

export default AddBookScreen;
