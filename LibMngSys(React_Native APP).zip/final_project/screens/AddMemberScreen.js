import React, { useState } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, Text, TextInput, Button, Alert, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

const SHEET_URL = 'https://api.sheetbest.com/sheets/795776a2-805c-4ab8-b921-7178d51b8aa2'; // 🔁 Replace with your Sheet.best URL

const AddMemberScreen = () => {
  const [form, setForm] = useState({
    ID: '',
    Title: '',
    Author: '',
    ISBN: '',
    Status: '',
    LastBorrowed: '',
    MemID: '',
    MemName: '',
    MemEmail: '',
    MemPhone: '',
    MembershipDate: '',
    BookID: '',
    MemberID: '',
    CheckoutDate: '',
    ReturnDate: '',
  });

  const handleChange = (key, value) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

 
  const handleSubmit = async () => {
    if (!form.MemID || !form.MemName || !form.MemEmail || !form.MemPhone) {
      Alert.alert('Validation Error', 'Please fill in all required fields.');
      return;
    }

    try {
      const response = await fetch(SHEET_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      if (response.ok) {
        Alert.alert('Success', 'Member added successfully!');
        setForm({
          ID: '',
          Title: '',
          Author: '',
          ISBN: '',
          Status: '',
          LastBorrowed: '',
          MemID: '',
          MemName: '',
          MemEmail: '',
          MemPhone: '',
          MembershipDate: '',
          BookID: '',
          MemberID: '',
          CheckoutDate: '',
          ReturnDate: '',
        });
      } else {
        Alert.alert('Error', 'Failed to add member.');
      }
    } catch (error) {
      console.error('AddMember Error:', error);
      Alert.alert('Error', 'Something went wrong.');
    }
  };

  const nav = useNavigation();


  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity onPress={() => nav.goBack()}>
        <Text style={{ fontSize: 18 }}>⬅️ Back</Text>
      </TouchableOpacity>
      <Text style={styles.title}>👤 Add New Member</Text>

      <TextInput
        placeholder="Member ID"
        value={form.MemID}
        onChangeText={text => handleChange('MemID', text)}
        style={styles.input}
      />
      <TextInput
        placeholder="Full Name"
        value={form.MemName}
        onChangeText={text => handleChange('MemName', text)}
        style={styles.input}
      />
      <TextInput
        placeholder="Email"
        value={form.MemEmail}
        onChangeText={text => handleChange('MemEmail', text)}
        style={styles.input}
        keyboardType="email-address"
      />
      <TextInput
        placeholder="Phone"
        value={form.MemPhone}
        onChangeText={text => handleChange('MemPhone', text)}
        style={styles.input}
        keyboardType="phone-pad"
      />
      <TextInput
        placeholder="Membership Date (YYYY-MM-DD)"
        value={form.MembershipDate}
        onChangeText={text => handleChange('MembershipDate', text)}
        style={styles.input}
      />

      <Button title="Add Member" onPress={handleSubmit} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#999',
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
    backgroundColor: '#fff',
  },
});

export default AddMemberScreen;
