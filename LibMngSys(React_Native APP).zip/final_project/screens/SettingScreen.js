import React from 'react';
import { View, Text, Button, Alert, StyleSheet,TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const SettingsScreen = () => {
  const handleResetWarning = () => {
    Alert.alert(
      'Reset Not Implemented',
      'Bulk reset must be done manually via the Google Sheet or with a backend script.\n\nFor safety, Sheet.best does not support deleting all rows at once.',
      [{ text: 'OK' }]
    );
  };

  const handleAbout = () => {
    Alert.alert(
      'About Library App',
      '📚 Library Management App\nVersion: 1.0\n\nBuilt with React Native + Google Sheets API (via Sheet.best).'
    );
  };
   
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
    <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={{ fontSize: 18 }}>⬅️ Back</Text>
      </TouchableOpacity>
  
      <Text style={styles.title}>Settings</Text>

      <View style={styles.buttonContainer}>
        <Button title="Reset All Data (Manual)" onPress={handleResetWarning} color="#e63946" />
      </View>

      <View style={styles.buttonContainer}>
        <Button title="About This App" onPress={() => navigation.navigate ('AboutScreen')} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    marginTop: 50,
  },
  title: {
    fontSize: 24,
    marginBottom: 30,
    fontWeight: 'bold',
  },
  buttonContainer: {
    marginBottom: 20,
  },
});

export default SettingsScreen;
