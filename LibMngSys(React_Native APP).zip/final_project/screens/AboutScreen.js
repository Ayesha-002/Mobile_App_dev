import React from 'react';
import { View, Text, StyleSheet, ScrollView, Linking, Button } from 'react-native';

const AboutScreen = () => {
  const handleContactPress = () => {
    Linking.openURL('mailto:fa22bscs0206@maju.edu.pk'); // Replace with your contact email
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>📘 About This App</Text>

      <Text style={styles.text}>
        This Library Management App is designed to help libraries easily manage their book inventory,
        track borrowing transactions, and maintain member records — all in one place.
      </Text>

      <Text style={styles.sectionTitle}>🔧 Features:</Text>
      <Text style={styles.text}>• Add and track books</Text>
      <Text style={styles.text}>• Register and manage members</Text>
      <Text style={styles.text}>• Monitor book status (available or borrowed)</Text>
      <Text style={styles.text}>• View transaction history</Text>
      <Text style={styles.text}>• Dashboard overview of library data</Text>

      <Text style={styles.sectionTitle}>📅 Version</Text>
      <Text style={styles.text}>1.0.0</Text>

      <Text style={styles.sectionTitle}>👨‍💻 Developed By</Text>
      <Text style={styles.text}>AYESHA RAUF</Text>

      <View style={{ marginTop: 20 }}>
        <Button title="Contact Developer" onPress={handleContactPress} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#f5f5f5',
    alignItems: 'center',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: 16,
    marginTop: 6,
    color: '#333',
    alignSelf: 'flex-start',
  },
});

export default AboutScreen;
