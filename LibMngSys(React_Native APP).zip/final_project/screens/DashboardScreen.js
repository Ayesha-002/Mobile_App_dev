import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, ScrollView, StyleSheet, RefreshControl } from 'react-native';


const SHEET_URL = 'https://api.sheetbest.com/sheets/795776a2-805c-4ab8-b921-7178d51b8aa2'; // Replace with your Sheet.best URL

const DashboardScreen = () => {
  const [data, setData] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      const response = await fetch(SHEET_URL);
      const json = await response.json();
      setData(json);
    } catch (error) {
      console.error('Dashboard fetch error:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  const totalBooks = data.filter(item => item.Title).length;
  const availableBooks = data.filter(item => item.Status?.toLowerCase() === 'available').length;
  const borrowedBooks = data.filter(item => item.Status?.toLowerCase() === 'borrowed').length;
  const members = new Set(data.map(item => item.MemID).filter(Boolean)).size;
  const totalTransactions = data.filter(item => item.CheckoutDate).length;

  return (
    <ScrollView
      contentContainerStyle={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <Text style={styles.title}>📊 Dashboard</Text>

      <View style={styles.card}>
        <Text style={styles.label}>📚 Total Books:</Text>
        <Text style={styles.value}>{totalBooks}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>✅ Available Books:</Text>
        <Text style={styles.value}>{availableBooks}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>📕 Borrowed Books:</Text>
        <Text style={styles.value}>{borrowedBooks}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>👥 Members:</Text>
        <Text style={styles.value}>{members}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>🔁 Total Transactions:</Text>
        <Text style={styles.value}>{totalTransactions}</Text>
      </View>

    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 60,
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  card: {
    width: '100%',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  label: {
    fontSize: 18,
    color: '#333',
  },
  value: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 5,
  },
});

export default DashboardScreen;
