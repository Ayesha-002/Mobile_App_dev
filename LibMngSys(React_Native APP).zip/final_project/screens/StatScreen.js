import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';

const SHEET_URL = 'https://api.sheetbest.com/sheets/795776a2-805c-4ab8-b921-7178d51b8aa2';

const StatusScreen = () => {
  const [data, setData] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const res = await fetch(SHEET_URL);
      const json = await res.json();
      setData(json);  // Fix here: setData directly as array
    } catch (error) {
      console.error('Status fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  const availableBooks = data.filter(item => item?.Status?.toLowerCase() === 'available');
  const borrowedBooks = data.filter(item => item?.Status?.toLowerCase() === 'borrowed');

  return (
    <ScrollView
      contentContainerStyle={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <Text style={styles.title}>📖 Book Status</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#555" />
      ) : (
        <>
          <View style={styles.card}>
            <Text style={styles.label}>✅ Available Books:</Text>
            <Text style={styles.count}>{availableBooks.length}</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.label}>📕 Borrowed Books:</Text>
            <Text style={styles.count}>{borrowedBooks.length}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.subTitle}>📚 List of Available Books:</Text>
            {availableBooks.map((book, index) => (
              <Text key={index} style={styles.item}>
                - {book.Title} ({book.Author})
              </Text>
            ))}
          </View>

          <View style={styles.section}>
            <Text style={styles.subTitle}>🔒 List of Borrowed Books:</Text>
            {borrowedBooks.map((book, index) => (
              <Text key={index} style={styles.item}>
                - {book.Title} ({book.Author})
              </Text>
            ))}
          </View>
        </>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 3,
  },
  label: {
    fontSize: 18,
    color: '#333',
  },
  count: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 4,
    color: '#007B55',
  },
  section: {
    marginTop: 20,
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
  },
  subTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  item: {
    fontSize: 14,
    marginBottom: 4,
    color: '#444',
  },
});

export default StatusScreen;
