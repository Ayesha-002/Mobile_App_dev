import React, { useEffect } from 'react';
import { View, FlatList, Text, ActivityIndicator } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchBooks } from '../redux/booksSlice';
import BookItem from '../components/BookItem'; // ✅ Correct relative path



export default function BooksScreen() {
  const dispatch = useDispatch();
  const { items, loading } = useSelector(state => state.books);

  useEffect(() => {
    dispatch(fetchBooks());
  }, [dispatch]);

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 30 }} />;

  return (
    <FlatList
      data={items}
      keyExtractor={(item, index) => index.toString()}
      renderItem={({ item }) => <BookItem book={item} />}
      
    />
  );
}


