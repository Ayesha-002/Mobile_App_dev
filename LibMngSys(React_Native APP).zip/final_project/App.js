import React from 'react';
import { SafeAreaView, SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider } from 'react-redux';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator} from '@react-navigation/bottom-tabs';


import store from './redux/Store';

import SettingScreen from './screens/SettingScreen';
import StatScreen from './screens/StatScreen';
import DashboardScreen from './screens/DashboardScreen';
import AboutScreen from './screens/AboutScreen';
import HomeStackNavigator from './navigation/HomeStackNavigator';
import BookScreen from './screens/BookScreen';
import GraphQL from './screens/GraphQL';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
    <Provider store={store}>
      <NavigationContainer>
        <SafeAreaView style={{ flex: 1 }}>
          <Tab.Navigator screenOptions={{ headerShown: false }}>
            <Tab.Screen name="Dashboard" component={DashboardScreen} />
            <Tab.Screen name="Home" component={HomeStackNavigator} />
            <Tab.Screen name="Status" component={StatScreen} />
            <Tab.Screen name="Books" component={BookScreen} />
            <Tab.Screen name="Settings" component={SettingScreen} />
            <Tab.Screen name="AboutScreen" component={AboutScreen} />
            <Tab.Screen name="GraphQL" component={GraphQL} />

            
          </Tab.Navigator>

        </SafeAreaView>
      </NavigationContainer>
    </Provider>
    </SafeAreaProvider>
  );
}
