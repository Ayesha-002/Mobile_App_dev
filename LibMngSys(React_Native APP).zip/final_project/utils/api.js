const SHEET_URL = 'https://api.sheetbest.com/sheets/795776a2-805c-4ab8-b921-7178d51b8aa2';

export async function fetchBooksFromSheet() {
  const res = await fetch(SHEET_URL);
  return await res.json();
}

export async function deleteBookFromSheet(id) {
  await fetch(`${SHEET_URL}/id/${id}`, { method: 'DELETE' });
}

export async function updateBookInSheet(id, updatedBook) {
  await fetch(`${SHEET_URL}/id/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updatedBook)
  });
}
